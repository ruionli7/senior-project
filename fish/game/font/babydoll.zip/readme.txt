FONTS BY DENISE BENTULAN

http://www.dafont.com/denise-bentulan.d2156

-----------------------------------------------------------------------------------------

Free for personal use ONLY.
For commercial use, please email the designer at dnn.bntln@yahoo.com

-----------------------------------------------------------------------------------------

PayPal donations are highly appreciated!
these help me in any way as an artist.
you may send them to my PayPal account, denise.bentulan@gmail.com (This may show up as Deniselarakamille General Merchandise on your statement as this is linked to my business account)

thank you.

-----------------------------------------------------------------------------------------
